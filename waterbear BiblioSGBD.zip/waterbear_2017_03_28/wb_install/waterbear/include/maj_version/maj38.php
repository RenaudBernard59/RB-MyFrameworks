﻿<?PHP 
// ancien timestamp : 1484067182 
// ancienne version : 37 
// ancien nom : 0.1.0 
// Pour faire une maj : copier le contenu de cette page et le coller dans un fichier maj38.php dans le repertoire include/maj_version 
// Ne pas oublier de modifier le script conf/version.php pour indiquer la derniere version 

// Ce traitement corrige un grave bug survenu durant la maj 37 (2 maj lancées en même temps) ce qui a créé de nombreux doublons dans le registre

$descriptif='???';
$nom='???';
$version='38';

// Une fois le patch appliqué, on supprime le contenu pour que ça ne soit pas appliqué sur les nouveaux comptes (ça ne sert qu'à corriger les anciens comptes)


?> 
