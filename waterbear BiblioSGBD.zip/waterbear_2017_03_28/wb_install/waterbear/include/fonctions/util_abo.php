<?php

function get_jour_de_la_semaine ($timestamp) {
    $retour=date("N", $timestamp);
    return ($retour);
}

function get_jour_de_la_semaine ($timestamp) {
    $retour=date("N", $timestamp);
    return ($retour);
}


?>