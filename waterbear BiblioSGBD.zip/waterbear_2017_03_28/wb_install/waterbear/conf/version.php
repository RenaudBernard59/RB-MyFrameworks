<?php

$GLOBALS["tvs_global"]["conf"]["version"]["version_soft"]=40;


?>