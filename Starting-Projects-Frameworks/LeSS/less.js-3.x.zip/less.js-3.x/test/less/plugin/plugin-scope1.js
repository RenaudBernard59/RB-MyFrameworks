functions.add('foo', function() {
    return "foo";
});